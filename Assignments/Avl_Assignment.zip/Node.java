/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dsalab.avl;

/**
 *
 * @author Super Galaxy
 */
class Node {
    int key;
    int height;
    Node left, right;

    Node(int d) {
        key = d;
        height = 1;
    }
}
