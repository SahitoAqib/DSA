//Muhammad Aaqib
//Section:B
//Roll No: Ari-f23-0067
//Course: DSA 
//Instructor: Sir ABdul Ghafoor
//Assignment No:3




/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package dsalab.avl;

/**
 *
 * @author Super Galaxy
 */
public class Avl {
    private Node root;
    public Avl() {
        root = null;
    }
    private int getHeight(Node node) {
    if (node == null) {
        return 0;
    } else {
        return node.height;
    }
}
   private int getBalanceFactor(Node node) {
    if (node == null) {
        return 0;
    } else {
        return getHeight(node.left) - getHeight(node.right);
    }
}
    private Node rightRotate(Node y) {
        Node x = y.left;
        y.left = x.right;
        x.right = y;
        y.height = Math.max(getHeight(y.left), 
                getHeight(y.right)) + 1;
        x.height = Math.max(getHeight(x.left), 
                getHeight(x.right)) + 1;
        return x;
    }
    private Node leftRotate(Node x) {
        Node y = x.right;
        x.right = y.left;
        y.left = x;
        x.height = Math.max(getHeight(x.left),
                getHeight(x.right)) + 1;
        y.height = Math.max(getHeight(y.left),
                getHeight(y.right)) + 1;
        return y;
    }
    public void insert(int key) {
        root = insert(root, key);
    }
    private Node insert(Node node, int key) {
        if (node == null) return new Node(key);
        if (key < node.key) node.left = insert(node.left, key);
        else if (key > node.key) node.right = insert(node.right, key);
        
        node.height = Math.max(getHeight(node.left), 
                getHeight(node.right)) + 1;
        int balance = getBalanceFactor(node);

        if (balance > 1 && key < node.left.key) 
            return rightRotate(node);
        if (balance < -1 && key > node.right.key)
            return leftRotate(node);
        if (balance > 1 && key > node.left.key) {
            node.left = leftRotate(node.left);
            return rightRotate(node);
        }
        if (balance < -1 && key < node.right.key) {
            node.right = rightRotate(node.right);
            return leftRotate(node);
        }
        return node;
    }
    public void delete(int key) {
        root = delete(root, key);
    }
    private Node delete(Node root, int key) {
        if (root == null) return root;
        if (key < root.key) root.left = delete(root.left, key);
        else if (key > root.key) root.right = delete(root.right, key);
        else {
            if (root.left == null || root.right == null)
                root = root.left != null ? root.left : root.right;
            else {
                Node temp = getMinValueNode(root.right);
                root.key = temp.key;
                root.right = delete(root.right, temp.key);
            }
        }
        if (root == null) return root;

        root.height = Math.max(getHeight(root.left), 
                getHeight(root.right)) + 1;
        int balance = getBalanceFactor(root);

        if (balance > 1 && getBalanceFactor(root.left) >= 0) 
            return rightRotate(root);
        if (balance > 1 && getBalanceFactor(root.left) < 0) {
            root.left = leftRotate(root.left);
            return rightRotate(root);
        }
        if (balance < -1 && getBalanceFactor(root.right) <= 0) 
            return leftRotate(root);
        if (balance < -1 && getBalanceFactor(root.right) > 0) {
            root.right = rightRotate(root.right);
            return leftRotate(root);
        }
        return root;
    }

    private Node getMinValueNode(Node node) {
        while (node.left != null) node = node.left;
        return node;
    }

    public boolean search(int key) {
        return search(root, key) != null;
    }

    private Node search(Node root, int key) {
    while (root != null) {
        if (key == root.key) {
            return root;  
        } else if (key < root.key) {
            root = root.left;  
        } else {
            root = root.right; 
        }
    }
    return null;  // Key not found
}
    public void inorder() {
        inorder(root);
        System.out.println();
    }

    private void inorder(Node root) {
        if (root != null) {
            inorder(root.left);
            System.out.print(root.key + " ");
            inorder(root.right);
        }
    }
    public static void main(String[] args) {
        Avl tree = new Avl();
        tree.insert(10);
        tree.insert(20);
        tree.insert(30);
        tree.insert(15);

        tree.inorder();

        System.out.println(tree.search(15)); 
        System.out.println(tree.search(100)); 

        tree.delete(20);
        tree.inorder();

        System.out.println(tree.search(20));  
    }
}

