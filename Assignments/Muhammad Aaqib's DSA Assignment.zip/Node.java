/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dsalab.bst_del;

/**
 *
 * @author Super Galaxy
 */
public class Node {
    int key;          // Value of the node
    Node left, right; // Pointers to left and right children

    // Constructor to initialize a node
    public Node(int item) {
        key = item;
        left = right = null;
    }
}

